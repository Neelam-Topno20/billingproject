package com.cg.mobilebilling.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.mobilebilling.beans.Plan;

public interface PlanDAOServices extends JpaRepository<Plan,Integer>{

	@Query(value="SELECT * FROM PLAN WHERE PLANID IN (SELECT PLAN_PLANID FROM POSTPAIDACCOUNT WHERE MOBILENO=?2 AND CUSTOMER_CUSTOMERID=?1 )",nativeQuery = true)
	public Plan findCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo);
}
