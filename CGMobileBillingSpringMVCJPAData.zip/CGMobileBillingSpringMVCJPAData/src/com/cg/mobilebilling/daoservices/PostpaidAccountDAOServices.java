package com.cg.mobilebilling.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mobilebilling.beans.PostpaidAccount;

public interface PostpaidAccountDAOServices extends JpaRepository<PostpaidAccount, Long>{
	
	@Query(value = "SELECT * FROM POSTPAIDACCOUNT WHERE CUSTOMER_CUSTOMERID = ?1  AND MOBILENO = ?2", nativeQuery = true)
	public PostpaidAccount findPostPaidAccountDetails(int customerID,long mobileNo);
	
	@Query(value = "SELECT * FROM POSTPAIDACCOUNT WHERE CUSTOMER_CUSTOMERID = ?1 ", nativeQuery = true)
	public List<PostpaidAccount> findCustomerAllPostpaidAccountsDetails(int customerID);

	@Modifying
	@Transactional
	@Query(value="UPDATE POSTPAIDACCOUNT SET PLAN_PLANID = ?3 WHERE MOBILENO = ?2 AND CUSTOMER_CUSTOMERID=?1",nativeQuery = true)
	public void changePlanDao(int customerID, long mobileNo, int planID);

	@Modifying
	@Transactional
	@Query(value=" DELETE FROM POSTPAIDACCOUNT WHERE CUSTOMER_CUSTOMERID=?2 AND MOBILENO = ?1",nativeQuery = true)
	public void closeCustomerPostPaidAccountDao( long mobileNo,int customerID);
}
