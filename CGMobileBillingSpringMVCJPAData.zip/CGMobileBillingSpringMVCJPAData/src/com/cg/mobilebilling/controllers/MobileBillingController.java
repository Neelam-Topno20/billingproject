package com.cg.mobilebilling.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class MobileBillingController {
	
	@Autowired
	BillingServices billingServices;
	
	@RequestMapping("/PlanAllDetails")
	public ModelAndView getPlanAllDetails() throws BillingServicesDownException {
		List<Plan> planList=billingServices.getPlanAllDetails();
		return new ModelAndView("viewAllPlansPage","planList", planList);
	}
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerDetails(@Valid@ModelAttribute Customer customer,BindingResult bindingResult) throws BillingServicesDownException {
		if(bindingResult.hasErrors())
			return new ModelAndView("acceptCustomerDetailsPage");
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registerSuccessPage","customer", customer);
	}
	
	@RequestMapping("/openAccount")
	public ModelAndView openAccount(@RequestParam("customerID")int customerID,
			@RequestParam("planID")int planID) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {

		PostpaidAccount postpaidAccount = billingServices.openPostpaidMobileAccount(customerID, planID);
		String message="Postpaid Account created with ID="+postpaidAccount.getMobileNo();
		return new ModelAndView("indexPage","message", message);
	}
	
	@RequestMapping("/generateBill")
	public ModelAndView generateBill(@RequestParam("customerID")int customerID,
			@RequestParam("mobileNo")Long mobileNo,@ModelAttribute Bill bill,BindingResult bindingResult
			) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {

		bill=billingServices.generateMonthlyMobileBill(customerID, mobileNo, bill.getBillMonth(), bill.getNoOfLocalSMS(), bill.getNoOfStdSMS(), bill.getNoOfLocalCalls(),bill.getNoOfStdCalls(), bill.getInternetDataUsageUnits());
		
		
		return new ModelAndView("billPrintPage","bill", bill);
	}
}
