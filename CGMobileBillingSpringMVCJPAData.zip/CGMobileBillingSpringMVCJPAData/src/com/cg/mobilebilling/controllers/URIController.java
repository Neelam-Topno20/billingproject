package com.cg.mobilebilling.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;

@Controller
public class URIController {
	
	Customer customer;
	Bill bill;
	
	@RequestMapping(value= {"/","/index","/home"})
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping(value= {"/acceptCustomerDetails"})
	public String getAcceptCustomerDetails() {
		return "acceptCustomerDetailsPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer= new Customer();
		return customer;
	}
	@ModelAttribute
	public Bill getBill() {
		bill= new Bill();
		return bill;
	}
	@RequestMapping(value= {"/openPostpaidMobileAccount"})
	public String getOpenPostpaidMobileAccount() {
		return "openPostpaidMobileAccountPage";
	}
	@RequestMapping(value= {"/generateMonthlyMobileBill"})
	public String getgenerateMonthlyMobileBill() {
		return "generateMonthlyMobileBillPage";
	}
}
