package com.cg.mobilebilling.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

@Component(value="billingServices")
public class BillingServicesImpl implements BillingServices {
	
	public BillingServicesImpl(CustomerDAOServices customerDaoServices) {
		super();
		this.customerDaoServices = customerDaoServices;
	}

	public BillingServicesImpl(PlanDAOServices planDaoServices) {
		super();
		this.planDaoServices = planDaoServices;
	}

	public BillingServicesImpl(PostpaidAccountDAOServices postpaidAccountDAOServices) {
		super();
		this.postpaidAccountDAOServices = postpaidAccountDAOServices;
	}

	public BillingServicesImpl() {
		super();
	}

	@Autowired
	PlanDAOServices planDaoServices;
	@Autowired
	CustomerDAOServices customerDaoServices;
	@Autowired
	PostpaidAccountDAOServices postpaidAccountDAOServices;
	@Autowired
	BillDAOServices billDAOServices;
	
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		
		return planDaoServices.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer){
		customer=customerDaoServices.save(customer);
		return customer;
	}

	@Override
	public PostpaidAccount openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDaoServices.findOne(customerID);
		Plan plan=planDaoServices.findOne(planID);
		PostpaidAccount postpaidAccount=new PostpaidAccount(plan, customer);
		postpaidAccount=postpaidAccountDAOServices.save(postpaidAccount);
		return postpaidAccount;
	}

	@Override
	public Bill generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findOne(mobileNo);
		Customer customer=customerDaoServices.findOne(customerID);
		Bill bill=new Bill( noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, postpaidAccount, customer);
		Plan plan=postpaidAccount.getPlan();
		bill.setInternetDataUsageAmount(plan.getInternetDataUsageRate()*internetDataUsageUnits);
		bill.setLocalCallAmount(plan.getLocalCallRate()*noOfLocalCalls);
		bill.setLocalSMSAmount(plan.getLocalSMSRate()*noOfLocalSMS);
		bill.setStdCallAmount(plan.getStdCallRate()*noOfStdCalls);
		bill.setStdSMSAmount(plan.getStdSMSRate()*noOfStdSMS);
		bill.setServicesTax(10);
		bill.setVat(10);
		float totalBillAmount=bill.getInternetDataUsageAmount()+bill.getLocalCallAmount()+bill.getLocalSMSAmount()+bill.getStdCallAmount()+bill.getStdSMSAmount();
		bill.setTotalBillAmount(totalBillAmount);
		bill=billDAOServices.save(bill);
		return bill;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		
		return customerDaoServices.findOne(customerID);
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
	
		return customerDaoServices.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		
		return postpaidAccountDAOServices.findPostPaidAccountDetails(customerID, mobileNo);
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		List<PostpaidAccount> customerAllPostpaidAccountsList=postpaidAccountDAOServices.findCustomerAllPostpaidAccountsDetails(customerID);
		Customer customer=customerDaoServices.findOne(customerID);
		Map<Long,PostpaidAccount> map=new HashMap<Long,PostpaidAccount>();
		for (PostpaidAccount postpaidAccount : customerAllPostpaidAccountsList) {
			map.put(postpaidAccount.getMobileNo(), postpaidAccount);
		}
		customer.setPostpaidAccounts(map);
		return customerAllPostpaidAccountsList;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
	
		return billDAOServices.findMobileBillDetails(customerID, mobileNo, billMonth);
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException{
		
		return billDAOServices.findCustomerPostPaidAccountAllBillDetails(customerID,mobileNo);
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		postpaidAccountDAOServices.changePlanDao(customerID, mobileNo, planID);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
	
		postpaidAccountDAOServices.closeCustomerPostPaidAccountDao(mobileNo, customerID);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		
		customerDaoServices.delete(customerID);
		return true ;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
	
		return planDaoServices.findCustomerPostPaidAccountPlanDetails(customerID, mobileNo);
	}



}